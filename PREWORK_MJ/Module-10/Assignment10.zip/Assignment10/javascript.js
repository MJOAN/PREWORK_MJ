function setGrow() {
	document.getElementById("box").style.width = "250px";
	document.getElementById("box").style.height = "250px";
}

function setBlue() {
	document.getElementById("box").style.backgroundColor = "blue";
}

function setFade() {
    document.getElementById("box").style.opacity = "0.5";
}

function resetImage() {
    document.getElementById("box").style.backgroundColor = "#FFA500";
    document.getElementById("box").style.opacity = "1";
    document.getElementById("box").style.height = "150px";
    document.getElementById("box").style.width = "150px";
    document.getElementById("box").style.margin = "25px";
}
